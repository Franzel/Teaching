//
//  square.cpp
//  vectorExample
//
//  Created by Francisco Zamorano on 12/7/12.
//
//

#include "square.h"

void square::setup(){
    
    
}

void square::update(){
    xPos+= 0.3;
    
}

void square::draw(float x, float y){

    ofRect(xPos, y, 50, 50);
    
    
}


